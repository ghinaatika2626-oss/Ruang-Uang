# Ruang Uang — proyek aplikasi Android

Aplikasi Android pribadi untuk mencatat pemasukan yang dialokasikan ke pribadi, pengeluaran pribadi, dan transfer tabungan. Data transaksi disimpan lokal di perangkat menggunakan SQLite.

## Fitur versi awal
- Dashboard anggaran bulanan (default Rp1.000.000)
- Tambah pemasukan pribadi, pengeluaran pribadi, dan transfer tabungan
- Kategori pengeluaran pribadi
- Laporan bulanan dan ringkasan per kategori
- Ekspor transaksi ke CSV
- Anggaran dapat diubah

## Batasan penting
- Aplikasi ini tidak terhubung otomatis ke rekening bank.
- Pemasukan klien MUA dan pengeluaran operasional MUA tidak dimasukkan sebagai transaksi pribadi. Catat hanya dana yang benar-benar dialokasikan dari usaha ke rekening/pribadi.
- Versi awal belum menyediakan impor/pemulihan backup otomatis. Ekspor CSV dapat dipakai sebagai salinan data transaksi.

## Cara membuat APK
1. Buka folder proyek ini di Android Studio (Open).
2. Tunggu Gradle Sync selesai. Pastikan Android SDK Platform 35 terpasang.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK hasil build biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Persyaratan build: Android Studio versi modern, JDK 17, Android SDK Platform 35, dan koneksi internet saat pertama kali mengunduh Gradle plugin.
